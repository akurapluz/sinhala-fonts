<?php
/**
 * Plugin Name: AkuraPluz
 * Plugin URI:  https://akurapluz.dulaksha.com
 * Description: Sinhala Fonts Library
 * Version:     1.0.0
 * Author:      Dulaksha
 * Author URI:  https://dulaksha.com
 * License:     GPL-2.0+
 * Text Domain: akurapluz
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function akurapluz_enqueue_styles() {
    wp_enqueue_style(
        'akurapluz-style',
        'https://cdn.akurapluz.dulaksha.com/style.css',
        array(),
        null
    );
}
add_action( 'wp_enqueue_scripts', 'akurapluz_enqueue_styles' );
